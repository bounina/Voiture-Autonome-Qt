#include "mainwindow.h"
#include "ui_mainwindow.h"
#include <QTcpServer>
#include <QTcpSocket>
#include <QLayout>


MainWindow::MainWindow(QWidget *parent)
    : QMainWindow(parent)
    , ui(new Ui::MainWindow)
    ,wiwi(parent,distances_mm)
{
    ui->setupUi(this);
    ui->lidar->layout()->addWidget(&wiwi);

    connect(ui->bp_on,&QPushButton::clicked,
            this,&MainWindow::allumerVoiture);

    connect(ui->bp_off,&QPushButton::clicked,
            this,&MainWindow::eteindreVoiture);

    connect(ui->bp_direction,&QPushButton::clicked,
            this,&MainWindow::testBoucleDirection);

    connect(ui->bp_vitesse,&QPushButton::clicked,
            this,&MainWindow::testBoucleVitesse);

    connect(&c1,&ClientTCP::newDatas,
            this,&MainWindow::processTableauLidar);

}


void MainWindow::processTableauLidar(QString message)

{
    QStringList array = message.split(';');

    if (array.size() == 360)
    {
        for(int i=0; i<= 359; i++)
        {
            distances_mm.at(i) = array.at(i).toInt();
        }
        wiwi.update();
    }

    else
    {
        ui->affichage->setText(message);
        ui->affichage->setAlignment(Qt::AlignCenter);

    }

}

void MainWindow::allumerVoiture()
{
    c1.sendDatas("on");
}

void MainWindow::eteindreVoiture()
{
    c1.sendDatas("off");
}

void MainWindow::testBoucleDirection()
{
    c1.sendDatas("test_angle");
}

void MainWindow::testBoucleVitesse()
{
    c1.sendDatas("test_vitesse");
}


MainWindow::~MainWindow()
{
    delete ui;
}






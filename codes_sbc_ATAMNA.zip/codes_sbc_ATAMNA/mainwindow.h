#ifndef MAINWINDOW_H
#define MAINWINDOW_H

#include <QMainWindow>

#include "clienttcp.h"
#include "widget_lidar.h"
#include <QTcpServer>


QT_BEGIN_NAMESPACE
namespace Ui {
class MainWindow;
}
QT_END_NAMESPACE

class MainWindow : public QMainWindow
{
    Q_OBJECT

public:
    MainWindow(QWidget *parent = nullptr);
    ~MainWindow();

public slots :
    // void afficherDonneesRecues(QString message);
    void processTableauLidar(QString message);
    void allumerVoiture();
    void eteindreVoiture();
    void testBoucleDirection();
    void testBoucleVitesse();

private:
    Ui::MainWindow *ui;
    ClientTCP c1{"10.57.3.19",8884};
    array<int,360>distances_mm;
    WidgetLIDAR wiwi;

signals:
    void newDatas();

};
#endif // MAINWINDOW_H
